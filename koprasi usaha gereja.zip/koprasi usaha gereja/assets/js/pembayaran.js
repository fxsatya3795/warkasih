const PAYMENT_CONFIG = {
    dataSource: "manual",
    apiBaseUrl: "https://api.example.com/v1",
    apiToken: "",
    authTokenKey: "loginToken"
};

function normalizeGoogleDriveImageUrl(value) {
    const raw = String(value ?? "").trim();
    if (!raw) return "";
    const matchFile = raw.match(/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]+)/i);
    if (matchFile) return `https://drive.google.com/uc?export=view&id=${matchFile[1]}`;
    const matchOpen = raw.match(/drive\.google\.com\/open\?id=([A-Za-z0-9_-]+)/i);
    if (matchOpen) return `https://drive.google.com/uc?export=view&id=${matchOpen[1]}`;
    const matchUC = raw.match(/drive\.google\.com\/uc\?export=view&id=([A-Za-z0-9_-]+)/i);
    if (matchUC) return `https://drive.google.com/uc?export=view&id=${matchUC[1]}`;
    return raw;
}

const checkout = JSON.parse(localStorage.getItem("visitorCheckout") || "null");
const cartKey = "visitorCart";
const activeOrderKey = "visitorActiveOrder";

class PaymentStorage {
    constructor(config) {
        this.config = config;
    }

    async saveOrder(order) {
        if (this.config.dataSource === "manual") {
            const orders = JSON.parse(localStorage.getItem("adminOrders") || "[]");
            orders.push(order);
            localStorage.setItem("adminOrders", JSON.stringify(orders));
            return order;
        }
        const sessionToken = sessionStorage.getItem("loginToken");
        const response = await fetch(`${this.config.apiBaseUrl.replace(/\/$/, "")}/orders`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                ...(sessionToken || this.config.apiToken
                    ? { Authorization: `Bearer ${sessionToken || this.config.apiToken}` }
                    : {})
            },
            body: JSON.stringify(order)
        });
        if (!response.ok) throw new Error(`API ${response.status}`);
        return response.json();
    }
}

const paymentStorage = new PaymentStorage(PAYMENT_CONFIG);

function generatePaymentCode(prefix = "KSR") {
    const randomPart = `${Date.now().toString().slice(-6)}${Math.random().toString().slice(-3)}`;
    return `${prefix}-${randomPart}`.toUpperCase();
}

function paymentCurrency(value) {
    return new Intl.NumberFormat("id-ID", {
        style: "currency", currency: "IDR", maximumFractionDigits: 0
    }).format(Number(value) || 0);
}

function renderPayment() {
    if (!checkout || !checkout.items?.length) {
        document.querySelector(".payment-layout").innerHTML = "<section class=\"payment-card\"><h2>Keranjang kosong</h2><a href=\"index.html\">Kembali ke menu</a></section>";
        return;
    }
    const subtotal = Number(checkout.subtotal) || checkout.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const delivery = checkout.type === "delivery" ? Number(checkout.deliveryCost) || 0 : 0;
    const method = checkout.payment || (checkout.type === "delivery" ? "transfer" : "pay_kasir");
    const methodLabel = method === "transfer" ? "Transfer Bank" : "Bayar di Kasir";
    const methodAlert = document.getElementById("paymentMethodAlert");
    if (methodAlert) methodAlert.textContent = `Metode pembayaran: ${methodLabel}`;
    const paymentButton = document.querySelector(".order-button");
    if (paymentButton) paymentButton.textContent = method === "pay_kasir"
        ? "Kirim Tagihan ke Kasir"
        : "Bayar dengan Transfer";
    document.querySelectorAll("input[name=payment]").forEach((input) => {
        input.checked = input.value === method;
        input.disabled = input.value !== method;
    });
    document.getElementById("paymentItems").innerHTML = checkout.items.map((item) => `
        <div class="payment-item">
            <span style="display:flex;align-items:center;gap:10px;">
                <img src="${item.image || item.icon || "img/images.png"}" alt="${item.name}" style="width:34px;height:34px;object-fit:cover;border-radius:8px;" onerror="this.onerror=null;this.src='img/images.png';" />
                ${item.name} x ${item.quantity}
            </span>
            <strong>${paymentCurrency(item.price * item.quantity)}</strong>
        </div>
    `).join("");
    document.getElementById("paymentSubtotal").textContent = paymentCurrency(subtotal);
    document.getElementById("paymentDelivery").textContent = paymentCurrency(delivery);
    document.getElementById("paymentTotal").textContent = paymentCurrency(subtotal + delivery);

    const barcodeBlock = document.getElementById("paymentBarcodeCard");
    if (barcodeBlock) {
        const paymentCode = method === "pay_kasir"
            ? (checkout.paymentCode || generatePaymentCode("KSR"))
            : (checkout.paymentCode || generatePaymentCode("TRF"));
        checkout.paymentCode = paymentCode;
        localStorage.setItem("visitorCheckout", JSON.stringify(checkout));
        barcodeBlock.innerHTML = `
            <div style="display:flex;flex-direction:column;gap:8px;align-items:center;">
                <span style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:#4a5568;">Kode pembayaran</span>
                <div style="width:100%;text-align:center;padding:12px;background:#111827;border-radius:12px;color:#fff;font-weight:700;letter-spacing:2px;font-family:ui-monospace,monospace;">${paymentCode}</div>
                <div style="display:flex;gap:4px;justify-content:center;flex-wrap:wrap;width:100%;max-width:240px;">
                    ${Array.from(paymentCode).map((char) => `<span style="display:inline-block;width:6px;height:22px;background:#1f2937;border-radius:999px;opacity:${(char.charCodeAt(0) % 5) + 1 > 5 ? 0.9 : 0.6};"></span>`).join("")}
                </div>
            </div>
        `;
        barcodeBlock.hidden = method !== "pay_kasir";
    }
}

async function processPayment() {
    if (!checkout?.items?.length) return window.alert("Tidak ada pesanan untuk dibayar.");
    const method = checkout.payment || (checkout.type === "delivery" ? "transfer" : "pay_kasir");
    const subtotal = Number(checkout.subtotal) || 0;
    const deliveryCost = Number(checkout.deliveryCost) || 0;
    const paymentCode = checkout.paymentCode || generatePaymentCode(method === "transfer" ? "TRF" : "KSR");
    const order = {
        id: `order-${Date.now()}`,
        number: `RB-${Date.now().toString().slice(-6)}`,
        customer: checkout.receiverName || JSON.parse(sessionStorage.getItem("userData") || "null")?.email || "Pengunjung",
        items: checkout.items,
        subtotal,
        deliveryCost,
        total: subtotal + deliveryCost,
        type: checkout.type || "dinein",
        payment: method,
        paymentCode,
        request: checkout.request || "",
        address: checkout.address || null,
        status: method === "pay_kasir" ? "menunggu_pembayaran" : "menunggu_verifikasi",
        createdAt: new Date().toISOString()
    };
    try {
        await paymentStorage.saveOrder(order);
        if (method === "pay_kasir") {
            localStorage.setItem(activeOrderKey, order.id);
            localStorage.setItem("visitorCheckout", JSON.stringify({ ...checkout, paymentCode }));
        }
        localStorage.removeItem(cartKey);
        localStorage.removeItem("visitorCheckout");
        if (method === "pay_kasir") {
            localStorage.setItem(activeOrderKey, order.id);
        }
        window.alert("Pesanan berhasil dikirim ke kasir.");
        window.location.href = "index.html";
    } catch (error) {
        console.error(error);
        window.alert("Pesanan gagal dikirim. Periksa koneksi API.");
    }
}

document.addEventListener("DOMContentLoaded", renderPayment);
window.processPayment = processPayment;
