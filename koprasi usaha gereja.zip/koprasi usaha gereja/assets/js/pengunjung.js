const VISITOR_CONFIG = {
    dataSource: "manual",
    apiBaseUrl: "http://localhost:3000/api",
    apiToken: ""
};

const VISITOR_KEYS = {
    products: "adminProducts",
    cart: "visitorCart",
    checkout: "visitorCheckout",
    activeOrder: "visitorActiveOrder",
    orders: "adminOrders"
};

class VisitorManualStorage {
    async getProducts() {
        try {
            return JSON.parse(localStorage.getItem(VISITOR_KEYS.products) || "[]");
        } catch (error) {
            console.error(error);
            return [];
        }
    }
}

class VisitorApiStorage {
    constructor(baseUrl, apiToken) {
        this.baseUrl = baseUrl.replace(/\/$/, "");
        this.apiToken = apiToken;
    }

    async getProducts() {
        const sessionToken = sessionStorage.getItem("loginToken");
        const response = await fetch(`${this.baseUrl}/products`, {
            headers: {
                "Content-Type": "application/json",
                ...(sessionToken || this.apiToken
                    ? { Authorization: `Bearer ${sessionToken || this.apiToken}` }
                    : {})
            }
        });
        if (!response.ok) throw new Error(`API ${response.status}`);
        return response.json();
    }
}

const visitorStorage = VISITOR_CONFIG.dataSource === "api"
    ? new VisitorApiStorage(VISITOR_CONFIG.apiBaseUrl, VISITOR_CONFIG.apiToken)
    : new VisitorManualStorage();

let visitorProducts = [];
let visitorCart = [];
let activeCategory = "makanan";

try {
    const savedCart = JSON.parse(localStorage.getItem(VISITOR_KEYS.cart) || "[]");
    visitorCart = Array.isArray(savedCart) ? savedCart.filter((item) => Number(item?.quantity || 0) > 0) : [];
    if (!visitorCart.length) {
        localStorage.setItem(VISITOR_KEYS.cart, JSON.stringify([]));
    }
} catch (error) {
    console.error(error);
    visitorCart = [];
    localStorage.setItem(VISITOR_KEYS.cart, JSON.stringify([]));
}

function visitorCurrency(value) {
    return new Intl.NumberFormat("id-ID", {
        style: "currency", currency: "IDR", maximumFractionDigits: 0
    }).format(Number(value) || 0);
}

function visitorEscape(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function normalizeGoogleDriveImageUrl(value) {
    const raw = String(value ?? "").trim();
    if (!raw) return "";
    const matchFile = raw.match(/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]+)/i);
    if (matchFile) return `https://drive.google.com/uc?export=view&id=${matchFile[1]}`;
    const matchOpen = raw.match(/drive\.google\.com\/open\?id=([A-Za-z0-9_-]+)/i);
    if (matchOpen) return `https://drive.google.com/uc?export=view&id=${matchOpen[1]}`;
    const matchUC = raw.match(/drive\.google\.com\/uc\?export=view&id=([A-Za-z0-9_-]+)/i);
    if (matchUC) return `https://drive.google.com/uc?export=view&id=${matchUC[1]}`;
    return raw;
}

function resolveProductImage(value, fallback = "img/images.png") {
    const rawValue = String(value ?? "").trim();
    if (!rawValue) return fallback;
    if (/^(https?:)?\/\//i.test(rawValue) || rawValue.startsWith("data:")) {
        return normalizeGoogleDriveImageUrl(rawValue);
    }
    const normalized = rawValue.replace(/\\/g, "/").replace(/^\/+/, "");
    const cleaned = normalized.startsWith("img/") || normalized.startsWith("image/")
        ? normalized
        : normalized.startsWith("./") ? normalized.slice(2) : normalized;
    const candidate = [
        cleaned,
        `img/${cleaned.replace(/^.*\//, "")}`,
        `image/${cleaned.replace(/^.*\//, "")}`,
        `img/${cleaned}`,
        `image/${cleaned}`,
        fallback
    ].find((item) => Boolean(item && item.trim()));
    return normalizeGoogleDriveImageUrl(candidate || fallback);
}

function saveVisitorCart() {
    localStorage.setItem(VISITOR_KEYS.cart, JSON.stringify(visitorCart));
}

function syncOrderPanelState() {
    const orderPanel = document.getElementById("orderPanel");
    if (!orderPanel) return;
    const shouldShow = Array.isArray(visitorCart) && visitorCart.length > 0;
    orderPanel.classList.toggle("show", shouldShow);
    if (!shouldShow) {
        orderPanel.classList.remove("show");
    }
}

function filteredProducts() {
    return activeCategory === "semua"
        ? visitorProducts
        : visitorProducts.filter((product) => product.category === activeCategory);
}

function renderVisitorProducts() {
    const grid = document.getElementById("productGrid");
    const productCount = document.getElementById("productCount");
    const products = filteredProducts();
    if (!grid) return;
    if (productCount) productCount.textContent = `${products.length} produk`;
    grid.innerHTML = products.length ? products.map((product) => {
        const stock = typeof product.stock === "number" ? product.stock : null;
        const unavailable = stock !== null && stock <= 0;
        const imageSrc = resolveProductImage(product.image || product.icon, "img/images.png");
        return `<article class="product-card">
            <div class="product-image">
                <img src="${imageSrc}" alt="${visitorEscape(product.name)}" onerror="this.onerror=null;this.src='img/images.png';" />
            </div>
            <div class="product-info">
                <span class="product-category">${visitorEscape(product.category || "produk")}</span>
                <h3 class="product-name">${visitorEscape(product.name)}</h3>
                <strong class="product-price">${visitorCurrency(product.price)}</strong>
                ${stock !== null ? `<small>Stok: ${stock}</small>` : ""}
                <button class="add-product" ${unavailable ? "disabled" : ""} onclick="addToCart('${visitorEscape(product.id)}')">
                    ${unavailable ? "Stok Habis" : "Tambah ke Pesanan"}
                </button>
            </div>
        </article>`;
    }).join("") : "<p>Belum ada produk yang tersedia.</p>";
}

function filterProduct(category) {
    activeCategory = category;
    document.querySelectorAll(".category").forEach((button) => {
        button.classList.toggle("active", button.textContent.toLowerCase().includes(category) || category === "semua" && button.textContent.trim() === "Semua");
    });
    renderVisitorProducts();
}

function addToCart(productId) {
    const product = visitorProducts.find((item) => item.id === productId);
    if (!product) return;
    const existing = visitorCart.find((item) => item.productId === productId);
    const stock = typeof product.stock === "number" ? product.stock : Infinity;
    if (existing) {
        if (existing.quantity >= stock) return window.alert("Jumlah pesanan melebihi stok.");
        existing.quantity += 1;
    } else {
        visitorCart.push({ productId, name: product.name, price: Number(product.price) || 0, image: product.image, quantity: 1 });
    }
    saveVisitorCart();
    renderCart();
    document.getElementById("orderPanel")?.classList.add("show");
}

function changeCartQuantity(productId, amount) {
    const item = visitorCart.find((cartItem) => cartItem.productId === productId);
    if (!item) return;
    item.quantity += amount;
    visitorCart = visitorCart.filter((cartItem) => cartItem.quantity > 0);
    saveVisitorCart();
    renderCart();
}

function visitorCartTotal() {
    return visitorCart.reduce((total, item) => total + item.price * item.quantity, 0);
}

function renderCart() {
    const items = document.getElementById("cartItems");
    if (!items) return;
    const quantity = visitorCart.reduce((total, item) => total + Number(item.quantity || 0), 0);
    const cartCount = document.getElementById("cartCount");
    const cartTotal = document.getElementById("cartTotal");
    if (cartCount) cartCount.textContent = `${quantity} item`;
    if (cartTotal) cartTotal.textContent = visitorCurrency(visitorCartTotal());
    if (!visitorCart.length) {
        items.innerHTML = "<p>Keranjang masih kosong.</p>";
        if (cartCount) cartCount.textContent = "0 item";
        if (cartTotal) cartTotal.textContent = visitorCurrency(0);
        syncOrderPanelState();
        return;
    }
    items.innerHTML = visitorCart.map((item) => `
        <div class="cart-item">
            <div style="display:flex;align-items:center;gap:10px;">
                <img src="${resolveProductImage(item.image || item.icon, "img/images.png")}" alt="${visitorEscape(item.name)}" style="width:38px;height:38px;object-fit:cover;border-radius:10px;" onerror="this.onerror=null;this.src='img/images.png';" />
                <div><strong>${visitorEscape(item.name)}</strong><small>${visitorCurrency(item.price)}</small></div>
            </div>
            <div class="cart-controls">
                <button onclick="changeCartQuantity('${visitorEscape(item.productId)}', -1)">-</button>
                <span>${item.quantity}</span>
                <button onclick="changeCartQuantity('${visitorEscape(item.productId)}', 1)">+</button>
            </div>
        </div>
    `).join("");
    syncOrderPanelState();
}

function closeOrderPanel() {
    const orderPanel = document.getElementById("orderPanel");
    if (!orderPanel) return;
    orderPanel.classList.remove("show");
    if (!visitorCart.length) {
        activeCategory = "makanan";
        filterProduct("makanan");
    }
}

function showOrderType() {
    if (!visitorCart.length) return window.alert("Tambahkan produk terlebih dahulu.");
    document.getElementById("orderTypeModal")?.classList.add("show");
}

function closeOrderType() {
    document.getElementById("orderTypeModal")?.classList.remove("show");
}

function selectOrderType(type) {
    const paymentMethod = type === "delivery" ? "Transfer Bank" : "Bayar di Kasir";
    window.alert(`Metode pembayaran untuk pesanan ini: ${paymentMethod}`);
    const checkout = {
        items: visitorCart,
        subtotal: visitorCartTotal(),
        type,
        payment: type === "delivery" ? "transfer" : "pay_kasir",
        request: document.getElementById("orderRequest")?.value.trim() || "",
        createdAt: new Date().toISOString()
    };
    localStorage.setItem(VISITOR_KEYS.checkout, JSON.stringify(checkout));
    closeOrderType();
    window.location.href = type === "delivery" ? "pesan-antar.html" : "pembayaran.html";
}

function openFooterPage(type) {
    const pages = {
        media: "https://www.instagram.com/",
        profil: "index.html",
        kontak: "mailto:admin@gmail.com"
    };
    window.open(pages[type] || "index.html", "_blank");
}

function logout() {
    sessionStorage.removeItem("loginToken");
    sessionStorage.removeItem("userData");
    window.location.href = "pengunjung.html";
}

function getCurrentReceiptOrder() {
    const orderId = localStorage.getItem(VISITOR_KEYS.activeOrder);
    if (!orderId) return null;
    try {
        const orders = JSON.parse(localStorage.getItem(VISITOR_KEYS.orders) || "[]");
        return orders.find((item) => item.id === orderId) || null;
    } catch (error) {
        console.error(error);
        return null;
    }
}

function printVisitorReceipt(order = null) {
    const selectedOrder = order || getCurrentReceiptOrder();
    if (!selectedOrder) {
        window.alert("Struk tidak tersedia untuk dicetak.");
        return;
    }

    const printWindow = window.open('', '_blank', 'width=800,height=900');
    if (!printWindow) {
        window.alert("Popup diblokir. Izinkan pop-up untuk mencetak PDF.");
        return;
    }

    const total = Number(selectedOrder?.paidTotal || selectedOrder?.total || 0);
    const rendered = `
        <html>
            <head>
                <title>Struk Pembelian</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 24px; color: #111827; }
                    .box { border: 1px solid #d1d5db; border-radius: 12px; padding: 18px; max-width: 500px; margin: 0 auto; }
                    h2 { margin: 0 0 12px; text-align: center; }
                    .row { display: flex; justify-content: space-between; margin: 8px 0; }
                    .total { font-weight: 700; border-top: 1px dashed #9ca3af; padding-top: 10px; }
                </style>
            </head>
            <body>
                <div class="box">
                    <h2>Struk Pembelian</h2>
                    <div class="row"><span>No. Pesanan</span><strong>${visitorEscape(selectedOrder?.number || selectedOrder?.id || "-")}</strong></div>
                    <div class="row"><span>Total</span><strong>${visitorCurrency(total)}</strong></div>
                    <div class="row"><span>Metode</span><strong>Pay Kasir</strong></div>
                    <div class="row"><span>Waktu</span><strong>${new Date(selectedOrder?.paidAt || Date.now()).toLocaleString("id-ID")}</strong></div>
                    <div class="row total"><span>Terima kasih</span><strong>Jemaat</strong></div>
                </div>
            </body>
        </html>
    `;

    printWindow.document.write(rendered);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
        printWindow.print();
    }, 300);
}

function renderVisitorOrderStatus(order) {
    const panel = document.getElementById("visitorOrderStatus");
    if (!panel || !order) return;
    const paid = ["siapkan_pesanan", "selesai", "paid", "dibayar"].includes(String(order.status).toLowerCase());
    panel.hidden = false;
    document.getElementById("visitorStatusIcon").textContent = paid ? "✅" : "⏳";
    document.getElementById("visitorStatusTitle").textContent = paid ? "Struk Pembelian" : "Menunggu Pembayaran";
    document.getElementById("visitorStatusMessage").textContent = paid
        ? "Pembayaran telah diterima kasir. Pesanan sedang disiapkan."
        : "Silakan lakukan pembayaran di kasir.";
    const receipt = document.getElementById("visitorReceipt");
    receipt.hidden = !paid;
    if (paid) receipt.innerHTML = `
        <div><span>No. Pesanan</span><strong>${visitorEscape(order.number || order.id)}</strong></div>
        <div><span>Total</span><strong>${visitorCurrency(order.paidTotal || order.total)}</strong></div>
        <div><span>Metode</span><strong>Pay Kasir</strong></div>
        <div><span>Waktu</span><strong>${new Date(order.paidAt || Date.now()).toLocaleString("id-ID")}</strong></div>
        <button type="button" onclick="printVisitorReceipt()" style="margin-top:12px; width:100%; background:#0f172a; color:#fff; border:none; border-radius:10px; padding:10px 14px; font-weight:700; cursor:pointer;">Cetak PDF</button>
    `;
}

function checkVisitorOrderStatus() {
    const orderId = localStorage.getItem(VISITOR_KEYS.activeOrder);
    if (!orderId) {
        const panel = document.getElementById("visitorOrderStatus");
        if (panel) panel.hidden = true;
        const receipt = document.getElementById("visitorReceipt");
        if (receipt) receipt.hidden = true;
        return;
    }
    let orders = [];
    try { orders = JSON.parse(localStorage.getItem(VISITOR_KEYS.orders) || "[]"); } catch (error) { return; }
    const order = orders.find((item) => item.id === orderId);
    if (order) renderVisitorOrderStatus(order);
}

async function loadVisitorProducts() {
    try {
        visitorProducts = await visitorStorage.getProducts();
        renderVisitorProducts();
        renderCart();
    } catch (error) {
        console.error(error);
        document.getElementById("productGrid").innerHTML = "<p>Menu gagal dimuat.</p>";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const userName = document.getElementById("userName");
    if (userName) {
        userName.textContent = JSON.parse(sessionStorage.getItem("userData") || "null")?.email || "Pengunjung";
    }
    localStorage.removeItem(VISITOR_KEYS.activeOrder);
    visitorCart = [];
    localStorage.setItem(VISITOR_KEYS.cart, JSON.stringify([]));
    renderCart();
    filterProduct("makanan");
    loadVisitorProducts();
    checkVisitorOrderStatus();
    document.addEventListener("click", (event) => {
        const panel = document.getElementById("orderPanel");
        if (!panel || !panel.classList.contains("show")) return;
        const clickedInsidePanel = event.target.closest("#orderPanel") || event.target.closest(".order-button") || event.target.closest(".cart-item") || event.target.closest(".add-product") || event.target.closest(".product-card") || event.target.closest(".category");
        if (!clickedInsidePanel) {
            closeOrderPanel();
        }
    });
    window.setInterval(checkVisitorOrderStatus, 2000);
});

window.filterProduct = filterProduct;
window.addToCart = addToCart;
window.changeCartQuantity = changeCartQuantity;
window.closeOrderPanel = closeOrderPanel;
window.showOrderType = showOrderType;
window.closeOrderType = closeOrderType;
window.selectOrderType = selectOrderType;
window.openFooterPage = openFooterPage;
window.logout = logout;
window.printVisitorReceipt = printVisitorReceipt;
