function generateBarcodePattern(code) {
    const seed = Array.from(code).map((char) => char.charCodeAt(0));
    const bars = [];
    for (let i = 0; i < 42; i += 1) {
        const value = (seed[i % seed.length] + i * 17) % 10;
        const height = 30 + (value % 6) * 8;
        bars.push(`<span style="height:${height}px; opacity:${0.45 + (value % 5) * 0.1};"></span>`);
    }
    return bars.join("");
}

function getCurrentPaymentCode() {
    const orderId = localStorage.getItem("visitorActiveOrder");
    const orders = JSON.parse(localStorage.getItem("adminOrders") || "[]");
    const activeOrder = orders.find((order) => order.id === orderId) || orders[orders.length - 1];
    return activeOrder?.paymentCode || "KSR-000000";
}

function renderBarcode() {
    const code = getCurrentPaymentCode();
    const codeEl = document.getElementById("paymentCode");
    const barsEl = document.getElementById("barcodeLines");
    if (codeEl) codeEl.textContent = code;
    if (barsEl) barsEl.innerHTML = generateBarcodePattern(code);
}

function goBackToMenu() {
    window.location.href = "index.html";
}

document.addEventListener("DOMContentLoaded", renderBarcode);
window.goBackToMenu = goBackToMenu;
