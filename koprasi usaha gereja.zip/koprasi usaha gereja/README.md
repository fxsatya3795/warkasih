# koprasi
